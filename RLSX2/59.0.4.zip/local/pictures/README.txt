This directory contains pictures of athletes in JPEG format.
The files must have a .jpg or .jpeg extension
The files are named according to the Membership field of the athlete

For example, athlete 4123 must have his/her picture in 4123.jpg or 4123.jpeg