Excel files placed in this directory will be read when the program starts.
The content of the files will replace the record definitions in the database.
The files are considered to be "official"
- If a new record was set during a competition, and the program is restarted, 
  the official data from the Excel file will be loaded again, and the old record will be used
  until the Excel is updated.

Examples of the Excel files can be found at   
https://www.dropbox.com/sh/sbr804kqfwkgs6g/AAAEcT2sih9MmnrpYzkh6Erma?dl=0

To add records for your federation, copy one of the files and rename it.
You can add as many age groups and body weight categories as you need.
The record name in column 2 can be translated to your local language.
