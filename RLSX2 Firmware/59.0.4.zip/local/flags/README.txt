This directory contains the flags in .svg or .png format

The file name must match exactly the team name (upper/lower case, accents, etc.)

example: If the team is Québec the file name must be either or
Québec.svg
Québec.png